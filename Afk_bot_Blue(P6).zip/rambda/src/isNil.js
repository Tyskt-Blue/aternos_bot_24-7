export function isNil(x){
  return x === undefined || x === null
}

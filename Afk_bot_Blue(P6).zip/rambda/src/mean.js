import { sum } from './sum'

export function mean(list){
  return sum(list) / list.length
}

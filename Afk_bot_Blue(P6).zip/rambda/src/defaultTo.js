function isFalsy(input){
  return (
    input === undefined ||
    input === null ||
    Number.isNaN(input) === true
  )
}

export function defaultTo(defaultArgument, input){
  if (arguments.length === 1){
    return _input =>
      defaultTo(defaultArgument, _input)
  }

  return isFalsy(input) ? defaultArgument : input
}

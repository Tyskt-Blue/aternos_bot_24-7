export const inc = x => x + 1

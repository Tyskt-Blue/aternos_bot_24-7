export function identity(input){
  return input
}

export function always(x){
  return () => x
}

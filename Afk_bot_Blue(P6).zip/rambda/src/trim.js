export function trim(str){
  return str.trim()
}

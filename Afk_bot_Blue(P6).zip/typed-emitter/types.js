// https://github.com/octokit/openapi-types.ts/issues/16#issuecomment-772784156

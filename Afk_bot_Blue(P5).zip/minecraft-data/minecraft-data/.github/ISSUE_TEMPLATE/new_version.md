---
name: New Version
about: Add a new minecraft version to MCD
title: 'Add version: '
---

- [ ] Version folder containing "version.json" created
- [ ] "version.json" filled out appropriately
- [ ] Added version to dataPath.json
- [ ] "version" field of dataPath.json points to new version folder
- [ ] Version added to common/versions.json
- [ ] Version added to ReadMe

Additional Requirements For This Update:
